This readme overviews what files are in this folder.


The "data" subfolder contains the .csv files necessary to run the IDDABEE pset.




"out" is where graphs produced by the R code are stored. 




"do" contains R code for producing the graphs in the "BEE exploring IDDA" exercises. Don't run this until after we've worked through the pset!! 

	IMPORTANT: The code should be modified to accommodate the specific parameters you choose and the filepath on your computer. 



