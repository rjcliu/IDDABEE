#   Description: This code pulls the IDDA data and produces a set of graphs on income levels and persistence for the BEE exercises. 
#
#   Date:   5/22/25
#   Author: RL






#set directories    
home <- "C:/Users/IRRJL01/Dropbox/personal/IDDA/BEEIDDA"       # <-  CHANGE THIS TO THE APPROPRIATE FILE DIRECTORY WHEN YOU FIRST RUN THE CODE
raw <- paste0(home,"/data") 
out <- paste0(home,"/out")



#load packages
#       NOTE: If you haven't run R before, you will likely have to install these packages using the command, install.packages("PACKAGE NAME HERE")
library(data.table)
library(tidyverse)
library(ggplot2)
library(ggrepel)
library(maps)
library(extrafont)
library(tidycensus)
library(tidyverse)
library(scales)




#load IDDA data
in_tm <- fread(paste(raw,"/transition_matrix_state_w2_5.csv",sep = ""))
in_pctls <- fread(paste(raw,"/pctl_of_inc_all_data.csv",sep = ""))






##############################
#     Tidying up
###############################

##    Initialize locals for remaining graphs <-  EVERYTHING IN THIS SECTION SHOULD BE CHANGED FOR YOUR PARAMETERS     



  #for reference 
in_pctls[group_var %in% c("xred","xsex","xfb","xaged"),.N,by = group_var_val] 

#pick two groups to compare
groups <- c("Female","Male") #order: num, denum 
groups <- setNames(groups, c("num","denum"))

#Pick percentile and year for graph A
pctls_A <-  c("pctl50")
y_A <-      2019


#Pick state for graph B
st_B <-     "MN"

#Pick percentile and year for graph C
pctls_C <-  c("pctl50")
y_C <-      2019


#Pick state for graph D 
st_D <-     "MN"


###############################################################

trim <- in_pctls[group_var_val %in% groups & samp == "all_w2_pik" & inc_var == "TC"] # --- trim data for just all_w2_pik & TC
trim <- trim[,gnum := ifelse(group_var_val == groups["num"], "num","denum")]



#Part A, create map of relative levels across states for a selected pctl + yr 
pctls <- pctls_A
y <- y_A

#tidy   
trim1 <- trim %>%
  filter(geo_var == "state" & year == y) %>%
  select(c("year","level","samp","inc_var","geo_var",
           "geo_var_val", "geo_abb", 
           "group_var", pctls, "gnum")) %>%
  pivot_wider(names_from = c("gnum"),values_from = pctls) %>%
  mutate(ratio = num/denum) 


#add state values to merge with spatial data
state_abbr_to_name <- setNames(tolower(state.name), state.abb)
trim1$state <- state_abbr_to_name[trim1$geo_abb]


us_map <- map_data("state")

map_df <- us_map %>%
  left_join(trim1,by = c("region" = "state"))

#draw graph
g1 <- map_df %>% 
  ggplot(aes(long, lat, group = group, fill = ratio)) +
  geom_polygon(color = "white") + 
  coord_fixed(1.3) + 
  scale_fill_viridis_c(option = "plasma", labels = percent_format(accuracy = 1)) + 
  labs(fill = "ratio", title = paste(groups["num"],"to", groups["denum"], "income ratio"), 
      subtitle = paste0(y,", ",pctls)) + 
  theme(panel.background = element_rect(fill = "white"),
        plot.background = element_rect(fill = "white"),
        panel.border = element_blank(),
        panel.grid.minor = element_blank(),
        panel.grid.major = element_blank(),
        plot.margin = margin(l=0.1,r=0.1,t=0.1,b=0.1, unit = "cm"))+
  guides(color = guide_legend(byrow = TRUE))

#export graph
ggsave(plot = g1, filename = paste0(out, "/heatmap_A.png"),
       height = 5.5, width =7, units = "in",  device = png)



#Part B, p10/50/98 relative income of two groups (within a group var val) in a selected state, over time 

st <- st_B

pctls <- c("pctl10","pctl50","pctl98")

#tidy data
trim2 <- trim %>%
  filter(geo_abb == st_B) %>%
  select(c("year","level","samp","inc_var","geo_var",
           "geo_var_val", "geo_abb", gnum, 
           "group_var", pctls)) %>%
  pivot_wider(names_from = gnum,values_from = pctls) %>%
  mutate(p10 = pctl10_num/pctl10_denum) %>%
  mutate(p50 = pctl50_num/pctl50_denum) %>%
  mutate(p98 = pctl98_num/pctl98_denum) %>%
  pivot_longer(c("p10","p50","p98"),names_to = "pct", names_prefix = "p")

#draw graph
g2 <- trim2 %>%
  ggplot(mapping = aes(x = year, y = value, color = pct)) + 
  geom_line() + 
  labs(title = paste(groups["num"],"to",groups["denum"],"relative income"), subtitle = st_B) + 
  theme(panel.background = element_rect(fill = "white"),
        plot.background = element_rect(fill = "white"),
        panel.border = element_blank(),
        panel.grid.minor = element_blank(),
        panel.grid.major = element_line(color = "grey90", linewidth = 0.15),
        plot.margin = margin(l=0.1,r=0.1,t=0.1,b=0.1, unit = "cm"))+
  guides(color = guide_legend(byrow = TRUE)) + 
  scale_y_continuous(name = "", labels = scales::percent_format())

  

#export graph
ggsave(plot = g2, filename = paste0(out, "/trendline_B.png"),
       height = 5.5, width =7, units = "in",  device = png)


#Part C, selected percentile ratio inequality against level percentile for selected year

pctls <- pctls_C
y <- y_C

#tidy data
trim3 <- trim %>%
  filter(year == y) %>%
  select(c("year","level","samp","inc_var","geo_var",
           "geo_var_val", "geo_abb", "gnum", 
           "group_var", pctls)) %>%
  pivot_wider(names_from = gnum,values_from = pctls) %>%
  mutate(ratio = num/denum)

#draw graph

g3 <- trim3 %>% 
  ggplot(mapping = aes(x = num, y = ratio)) + 
  geom_point() + 
  labs(title = paste(groups["num"],"to",groups["denum"],"relative income"), subtitle = paste(pctls,",", y)) + 
  ylab("") +
  scale_y_continuous(name = "", 
                     labels = scales::percent_format()) + 
  scale_x_continuous(name = paste(groups["num"], "income level across states"), labels = scales::dollar_format(scale = .001, suffix = "K"))

#export graph 
ggsave(plot = g3, filename = paste0(out, "/trendline_C.png"),
       height = 5.5, width =7, units = "in",  device = png)

#Part D, create map of 5-year top persistence by group, across a state
st <- st_D



trim4 <- in_tm[group_var_val %in% groups 
               & samp == "all_w2_pik" 
               & inc_var == "TC" 
               & pctl_y0 == "gt75" 
               & pctl_y0 == pctl_y1 
               & geo_abb %in% c(st,"US") 
               & lag == 5]

g4<- trim4 %>% 
  ggplot(mapping = aes(x = y0, y = probability, color = group_var_val)) + 
  geom_line() + 
  theme(panel.background = element_rect(fill = "white"),
        plot.background = element_rect(fill = "white"),
        panel.border = element_blank(),
        panel.grid.minor = element_blank(),
        panel.grid.major = element_line(color = "grey90", linewidth = 0.15),
        plot.margin = margin(l=0.1,r=0.1,t=0.1,b=0.1, unit = "cm"))+
  guides(color = guide_legend(byrow = TRUE)) + 
  scale_y_continuous(name = "", labels = scales::percent_format()) + 
  labs(title = "Persistence of top incomes", subtitle = paste(st,", 5 year lag")) +
  scale_x_continuous(breaks = seq(2005, 2014, by = 2))

ggsave(plot = g4, filename = paste0(out, "/trendline_D.png"),
       height = 5.5, width =7, units = "in",  device = png)






